package sample;

public class A {
	int a=20;
	static int b=30;
	int display()
	{
		return (20);
	}
	static void display1()
	{
		System.out.println("25");
	}
	

}
