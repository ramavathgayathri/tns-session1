package core;

public class userdefined {
	int i=4;
	static int b=4;
	int display() {
		return 1;
	}
	static void display1() {
		System.out.println("12");
	}
	public static void main(String[] args) {
		int j=3;
		System.out.println(j);
		userdefined c1=new userdefined();
		System.out.println(c1.i);
		c1.display();
		System.out.println(userdefined.b);
		userdefined.display1();
		// TODO Auto-generated method stub

	}

}
