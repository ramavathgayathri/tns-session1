package p1;

public class A {

	private void display() {
		System.out.println("tns sessions");
	}

	public static void main(String[] args) {
		A obj=new A();
		obj.display();
		

	}

		
	}


