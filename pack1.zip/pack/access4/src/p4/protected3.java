 package p4;

public class protected3  extends protectedp2{

	public static void main(String[] args) {
		protectedp2 obj5 =new protectedp2();
		obj5.display4();

	}

}
