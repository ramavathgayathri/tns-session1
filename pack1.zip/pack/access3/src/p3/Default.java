package p3;

public class Default {
	void display() {
		System.out.println("default access modifier");
	}

	public static void main(String[] args) {
		Default obj3=new Default();
		obj3.display();
		// TODO Auto-generated method stub

	}

}
