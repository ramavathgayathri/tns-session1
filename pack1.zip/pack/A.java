package pack;

public class A {
	int a=30;
	static int b=25;
	   int display()
	{
		   return 10;
		
	}
	   static void display1()
	   {
		   System.out.println("10");
	   }
	   public class B{
		  public static void main(String args[])

		   int c=11;
		   System.out.println(c);
		   A.obj=new A();
		   System.out.println(obj.a);
		   System.out.println(A.b);
		   obj.display()
		   A.display1();
	   }
		
	   
		   
	   
	  
	 

}
