package pack;

public class A {
	int a=10;
	static int b=15;
	int display()
	{
		return 10;
	}
	static void display1()
	{
		System.out.println("10");
	}

	public static void main(String[] args) {
		int c=20;
		System.out.println(c);
		A obj=new A();
		System.out.println(obj.a);
		System.out.println(A.b);
		obj.display();
		A.display1();
		// TODO Auto-generated method stub

	}

}
